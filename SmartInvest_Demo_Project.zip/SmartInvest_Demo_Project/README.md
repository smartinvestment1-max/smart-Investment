# SmartInvest demo project

A standalone VS Code starter for the SmartInvest dark-navy/emerald UI, 10 sample investment plan cards, and a manual deposit-review demonstration.

## Important
This is a **demo-only prototype**, not a real investment or payment service. The plan percentages are supplied sample values and are not a promise or guarantee of returns. The deposit form records a request for review; it does not contact JazzCash/EasyPaisa/banks, verify payment, transfer funds, or credit a wallet. Do not use real payment receipts or expose this demo publicly.

## Requirements
- Node.js 18+ (or current LTS)
- VS Code

## Run
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. In the terminal run:

   ```bash
   npm install
   npm start
   ```

4. Open `http://localhost:3000` for the user demo.
5. Open `http://localhost:3000/admin.html` for the admin review demo.

Default local demo admin key: `demo-admin-change-me`.

For local testing, you can set a different key before starting:
- Windows PowerShell: `$env:ADMIN_KEY="your-local-demo-key"; npm start`
- macOS/Linux: `ADMIN_KEY="your-local-demo-key" npm start`

## Included
- `server.js`: Express API, plan data, demo deposit submission, admin review.
- `public/index.html`: mobile-friendly app page.
- `public/styles.css`: dark navy and emerald theme.
- `public/app.js`: plan rendering, details modal, demo deposit form and request status.
- `admin.html`: separate admin review page.
- `data/deposits.json`: local demo requests (created on first run).
- `uploads/`: locally stored demo receipt images.

## Calculation
Daily projected profit = investment × daily rate ÷ 100.
Total projected profit = daily projected profit × validity days.
Total amount = investment + total projected profit.

The app labels these as projections and makes no guarantee. Have qualified professionals review the product, legal/regulatory requirements, security, privacy, and payment integrations before any real-money deployment.
