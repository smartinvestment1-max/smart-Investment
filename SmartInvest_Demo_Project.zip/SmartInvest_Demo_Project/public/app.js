const money = n => "PKR " + Number(n).toLocaleString("en-PK", {minimumFractionDigits:0, maximumFractionDigits:2});
const accents = ["#00c98d","#258bff","#8b5cf6","#f59e0b","#f43f7a","#06b6d4","#84cc16","#f97316","#14b8a6","#6366f1"];
const views = ["plans","deposit","status"];
function showView(name) {
  views.forEach(v => document.getElementById(v+"View").classList.toggle("hidden", v !== name));
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.view === name));
}
document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => showView(b.dataset.view)));

async function loadPlans() {
  const container = document.getElementById("plans");
  try {
    const response = await fetch("/api/plans");
    const data = await response.json();
    container.innerHTML = data.plans.map((p, i) => `
      <article class="plan-card" style="--accent:${accents[i]}">
        <div class="plan-top"><div class="plan-icon">${String(i+1).padStart(2,"0")}</div><div><h3>Plan ${p.id}</h3><small>${p.days} days · Demo projection</small></div></div>
        <div class="amount">${money(p.investment)} <small>investment</small></div>
        <div class="metric"><span>Daily rate</span><b>${p.dailyRate}%</b></div>
        <div class="metric"><span>Daily projected profit</span><b>${money(p.dailyProfit)}</b></div>
        <div class="metric"><span>Validity</span><b>${p.days} days</b></div>
        <div class="metric"><span>Total projected profit</span><b>${money(p.totalProfit)}</b></div>
        <div class="metric total"><span>Principal + projection</span><b>${money(p.totalAmount)}</b></div>
        <div class="card-actions"><button class="primary" onclick="showPlan(${p.id})">View Details</button></div>
      </article>`).join("");
    window.planData = data.plans;
  } catch {
    container.innerHTML = '<p class="muted">Could not load plans. Start the server and refresh.</p>';
  }
}
window.showPlan = id => {
  const p = (window.planData || []).find(x => x.id === id);
  if (!p) return;
  document.getElementById("planDetails").innerHTML = `
    <p class="eyebrow">PLAN DETAILS · DEMO</p><h2>Plan ${p.id}</h2>
    <p class="muted">${p.days}-day sample calculation</p>
    <div class="amount">${money(p.investment)}</div>
    <div class="metric"><span>Daily rate</span><b>${p.dailyRate}%</b></div>
    <div class="metric"><span>Daily projected profit</span><b>${money(p.dailyProfit)}</b></div>
    <div class="metric"><span>Validity</span><b>${p.days} days</b></div>
    <div class="metric"><span>Total projected profit</span><b>${money(p.totalProfit)}</b></div>
    <div class="metric total"><span>Total incl. principal</span><b>${money(p.totalAmount)}</b></div>
    <p class="notice" style="margin-top:16px">Illustrative arithmetic only. This demo does not accept investments or guarantee returns.</p>`;
  document.getElementById("planDialog").showModal();
};
document.getElementById("closeDialog").addEventListener("click", () => document.getElementById("planDialog").close());

document.getElementById("depositForm").addEventListener("submit", async e => {
  e.preventDefault();
  const form = e.currentTarget, msg = document.getElementById("formMessage");
  msg.textContent = "Submitting demo request…";
  try {
    const response = await fetch("/api/deposits", { method:"POST", body:new FormData(form) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not submit request.");
    msg.textContent = data.message;
    form.reset();
    await loadRequests();
    showView("status");
  } catch (err) { msg.textContent = err.message; }
});

async function loadRequests() {
  const box = document.getElementById("requests");
  try {
    const response = await fetch("/api/admin/deposits", {headers:{"x-admin-key":"demo-admin-change-me"}});
    const rows = await response.json();
    if (!response.ok) throw new Error(rows.error || "Unable to load demo requests.");
    if (!rows.length) { box.innerHTML = '<p class="muted">No demo requests submitted yet.</p>'; return; }
    box.innerHTML = rows.map(r => `<article class="request-card">
      <div><strong>${escapeHtml(r.userName)}</strong><div class="muted">${money(r.amount)} · ${escapeHtml(r.method)} · ${new Date(r.createdAt).toLocaleString()}</div><small class="muted">Ref: ${escapeHtml(r.transactionId)}</small></div>
      <span class="status ${r.status}">${r.status}</span>
    </article>`).join("");
  } catch (e) { box.innerHTML = `<p class="muted">${escapeHtml(e.message)}</p>`; }
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
document.getElementById("refreshRequests").addEventListener("click", loadRequests);
loadPlans();