const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || "demo-admin-change-me";
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "uploads");
const DB_FILE = path.join(DATA_DIR, "deposits.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(UPLOAD_DIR));

const plans = [
  { id: 1, investment: 150, dailyRate: 20, days: 30 },
  { id: 2, investment: 250, dailyRate: 22, days: 35 },
  { id: 3, investment: 350, dailyRate: 24, days: 40 },
  { id: 4, investment: 500, dailyRate: 26, days: 45 },
  { id: 5, investment: 750, dailyRate: 28, days: 50 },
  { id: 6, investment: 1000, dailyRate: 30, days: 55 },
  { id: 7, investment: 1500, dailyRate: 32, days: 60 },
  { id: 8, investment: 2000, dailyRate: 34, days: 65 },
  { id: 9, investment: 3000, dailyRate: 36, days: 70 },
  { id: 10, investment: 4000, dailyRate: 38, days: 75 }
].map(p => ({
  ...p,
  dailyProfit: Math.round(p.investment * p.dailyRate) / 100,
  totalProfit: Math.round(p.investment * p.dailyRate * p.days) / 100,
  totalAmount: p.investment + Math.round(p.investment * p.dailyRate * p.days) / 100
}));

function readDeposits() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return []; }
}
function writeDeposits(rows) {
  fs.writeFileSync(DB_FILE, JSON.stringify(rows, null, 2));
}
function adminOnly(req, res, next) {
  if (req.get("x-admin-key") !== ADMIN_KEY) {
    return res.status(401).json({ error: "Admin access denied. Set the X-Admin-Key header." });
  }
  next();
}
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 8);
    cb(null, `${Date.now()}-${crypto.randomBytes(5).toString("hex")}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 4 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/png", "image/jpeg", "image/webp"];
    cb(allowed.includes(file.mimetype) ? null : new Error("Upload PNG, JPG, or WEBP only."), allowed.includes(file.mimetype));
  }
});

app.get("/api/plans", (_req, res) => {
  res.json({ demoOnly: true, currency: "PKR", plans });
});

// DEMO FLOW ONLY: this records a request for admin review; it does not initiate or verify a payment.
app.post("/api/deposits", upload.single("receipt"), (req, res) => {
  const amount = Number(req.body.amount);
  const transactionId = String(req.body.transactionId || "").trim();
  const method = String(req.body.method || "").trim();
  const userName = String(req.body.userName || "").trim();
  if (!Number.isFinite(amount) || amount < 1 || amount > 10000000) {
    return res.status(400).json({ error: "Enter a valid PKR amount." });
  }
  if (!transactionId || transactionId.length > 120) {
    return res.status(400).json({ error: "Transaction ID is required (max 120 characters)." });
  }
  if (!["JazzCash", "EasyPaisa", "Bank Transfer", "Demo"].includes(method)) {
    return res.status(400).json({ error: "Select a supported demo payment method." });
  }
  if (!req.file) return res.status(400).json({ error: "Upload a payment receipt image." });

  const rows = readDeposits();
  const item = {
    id: crypto.randomUUID(),
    userName: userName || "Demo User",
    amount,
    currency: "PKR",
    method,
    transactionId,
    receiptUrl: `/uploads/${req.file.filename}`,
    status: "Pending",
    createdAt: new Date().toISOString(),
    reviewedAt: null,
    adminNote: ""
  };
  rows.unshift(item);
  writeDeposits(rows);
  res.status(201).json({
    message: "Demo request submitted for review. No money was transferred or credited.",
    deposit: item
  });
});

app.get("/api/admin/deposits", adminOnly, (_req, res) => {
  res.json(readDeposits());
});

app.patch("/api/admin/deposits/:id", adminOnly, (req, res) => {
  const status = String(req.body.status || "");
  const note = String(req.body.note || "").trim().slice(0, 500);
  if (!["Approved", "Rejected"].includes(status)) {
    return res.status(400).json({ error: "Status must be Approved or Rejected." });
  }
  const rows = readDeposits();
  const row = rows.find(d => d.id === req.params.id);
  if (!row) return res.status(404).json({ error: "Deposit request not found." });
  if (row.status !== "Pending") return res.status(409).json({ error: "This request has already been reviewed." });
  row.status = status;
  row.adminNote = note;
  row.reviewedAt = new Date().toISOString();
  writeDeposits(rows);
  res.json({ message: `Demo request marked ${status.toLowerCase()}. No balance was credited.`, deposit: row });
});

app.get("/api/health", (_req, res) => res.json({ ok: true, mode: "DEMO_ONLY" }));

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Request failed." });
});

app.listen(PORT, () => {
  console.log(`SmartInvest demo running at http://localhost:${PORT}`);
  console.log("DEMO ONLY: no real payments, wallet credits, or investment execution.");
});